#![cfg(feature = "postgres")]

use spectra_core::Json;
use spectra_db::{connect, migrate, new_id, PoolConfig};
use spectra_engine::{config_fingerprint, BacktestConfig, Metrics, RunRecord};
use spectra_registry::{PgRegistry, Registry, RunFilter, RunInput};
use spectra_research::ParamSet;

async fn database_registry() -> Option<(PgRegistry, spectra_db::PgPool)> {
    let url = std::env::var("DATABASE_URL").ok()?;
    let pool = connect(&PoolConfig::new(url)).await.expect("DATABASE_URL must be reachable");
    migrate(&pool).await.expect("migrations must apply");
    let workspace_id = new_id();
    let slug = format!("m5-{}", workspace_id.simple());
    sqlx::query("INSERT INTO workspaces (id, slug, name) VALUES ($1, $2, 'M5 integration test')")
        .bind(workspace_id)
        .bind(slug)
        .execute(&pool)
        .await
        .expect("test workspace must be created");
    Some((PgRegistry::new(pool.clone(), workspace_id), pool))
}

#[tokio::test]
async fn postgres_registry_commits_projections_and_exportable_chain_atomically() {
    let Some((registry, _pool)) = database_registry().await else { return };

    let parent = registry
        .create_experiment("baseline", "The baseline is reproducible", &["daily", "control"], "", None)
        .await
        .unwrap();
    let child =
        registry.fork_experiment(&parent, "variant", "Change one parameter", &["daily"], None).await.unwrap();
    assert_eq!(registry.lineage(&child).await.unwrap(), vec![parent.clone(), child.clone()]);

    let config = BacktestConfig::default();
    let input = RunInput {
        experiment_id: child.clone(),
        kind: "backtest".into(),
        dataset_id: "dataset-v1".into(),
        strategy: "buy-and-hold".into(),
        strategy_sha256: "b".repeat(64),
        params: ParamSet::default(),
        config,
        run: RunRecord {
            engine_version: "test-engine".into(),
            dataset_sha256: "a".repeat(64),
            config_sha256: config_fingerprint(&config),
            result_sha256: "d".repeat(64),
            seed: 7,
            bar_count: 3,
        },
        metrics: Metrics::default(),
        returns: vec![0.01, -0.02, 0.03],
        counts_as_trial: true,
        note: String::new(),
    };
    let run_id = registry.record_run(&input, None).await.unwrap();
    let run = registry.run(&run_id).await.unwrap().unwrap();
    assert_eq!(run.status, "succeeded");
    assert_eq!(run.dataset_bars_sha256, "a".repeat(64));
    assert_eq!(registry.trial_count(Some(&child)).await.unwrap(), 1);

    let artifact_id = registry
        .record_artifact(
            &child,
            &run_id,
            "equity_curve",
            b"equity-series",
            "sha256/ab/cd/example",
            Json::object().with("points", Json::integer(3)),
        )
        .await
        .unwrap();
    registry.add_note(&run_id, "Reviewed against the source data", None).await.unwrap();
    let artifacts = registry.artifacts(&child).await.unwrap();
    assert_eq!(artifacts.len(), 1);
    assert_eq!(artifacts[0].id, artifact_id);
    assert_eq!(registry.verify().await.unwrap().events, 5);

    let export = registry.export_jsonl().await.unwrap();
    let Some((imported, _)) = database_registry().await else { unreachable!("database remains configured") };
    assert_eq!(imported.import_jsonl(&export).await.unwrap(), 5);
    assert_eq!(imported.export_jsonl().await.unwrap(), export);
    assert!(imported.verify().await.unwrap().ok);
    assert_eq!(imported.experiments().await.unwrap().len(), 2);
    assert_eq!(imported.runs(&RunFilter::default()).await.unwrap().len(), 1);

    let temp = std::env::temp_dir().join(format!("spectra-pg-registry-{}", new_id()));
    std::fs::create_dir_all(&temp).unwrap();
    std::fs::write(temp.join("registry.jsonl"), export).unwrap();
    let mut file_registry = Registry::open(&temp).unwrap();
    assert!(file_registry.verify().ok);
    assert_eq!(file_registry.experiments().unwrap().len(), 2);
    assert_eq!(file_registry.runs(&RunFilter::default()).unwrap().len(), 1);
    std::fs::remove_dir_all(temp).unwrap();
}
